<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="64"/>
        <source>MX Repo Manager</source>
        <translation>MX 软件仓库管理器</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="860"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>请选择您想要使用的 APT 软件仓库（软件源）：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>MX 软件仓库</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>为我选择最快的 MX 软件仓库</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Debian 软件仓库</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>为我选取最快的 Debian 软件仓库</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>独立软件源</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>恢复原 APT 软件源</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>显示帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>关于此软件</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>关于…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>退出应用程序</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Success</source>
        <translation>成功</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <location filename="../src/mainwindow.cpp" line="1065"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>你的新选择将在下一次软件源更新时生效。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="194"/>
        <source>No Changes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>The selected repository is already configured.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Lists</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>软件源（打钩的软件源是已经启用的）</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="949"/>
        <location filename="../src/mainwindow.cpp" line="964"/>
        <location filename="../src/mainwindow.cpp" line="977"/>
        <location filename="../src/mainwindow.cpp" line="984"/>
        <location filename="../src/mainwindow.cpp" line="998"/>
        <location filename="../src/mainwindow.cpp" line="1006"/>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <source>Could not change the repo.</source>
        <translation>无法更改软件仓库</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="690"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>Please wait...</source>
        <translation>请稍等...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="784"/>
        <source>About %1</source>
        <translation>关于 %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Version: </source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>Program for choosing the default APT repository</source>
        <translation>这是一个选择默认 APT 软件仓库的应用程序</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="789"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="790"/>
        <source>%1 License</source>
        <translation>%1 许可证</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="804"/>
        <source>%1 Help</source>
        <translation>%1 帮助</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="821"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="822"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>您已选中 MX 测试仓库。不建议启用该仓库，也不建议从该仓库升级所有的软件包。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>更安全的选择是在 MX 软件包安装器中单独安装这些软件包。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="862"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>请选中您想使用的 APT 软件仓库和软件源：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt 无法检测最快的软件仓库。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Could not restore the original APT source files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="949"/>
        <location filename="../src/mainwindow.cpp" line="964"/>
        <source>Could not detect fastest repo.</source>
        <translation>无法检测最快的软件仓库。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="977"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="985"/>
        <source>MX version not detected or out of range: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="998"/>
        <source>Could not download original APT files.</source>
        <translation> 无法下载原 APT 文件。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1006"/>
        <source>Could not unzip downloaded file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>Enabling AHS</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>原 APT 软件源已被恢复至 Release 状态。用户添加在 /etc/apt/sources.list.d/ 中的软件源文件不会被使用。</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="49"/>
        <source>License</source>
        <translation>许可证</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="50"/>
        <location filename="../src/about.cpp" line="60"/>
        <source>Changelog</source>
        <translation>更新日志</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>您似乎是以 root 身份登录的，请注销并以普通用户身份登录以使用该程序。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation>您必须以管理员权限运行此程序。</translation>
    </message>
</context>
</TS>