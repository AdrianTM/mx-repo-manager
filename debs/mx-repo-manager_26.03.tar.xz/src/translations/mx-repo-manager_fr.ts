<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="17"/>
        <location filename="../src/mainwindow.cpp" line="64"/>
        <source>MX Repo Manager</source>
        <translation>MX Gestionnaire de dépôts - MX Repo Manager</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="32"/>
        <location filename="../src/mainwindow.cpp" line="860"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Sélectionnez le dépôt APT que vous souhaitez utiliser :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>Dépots MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Sélectionner le dépôt MX le plus rapide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Dépôts Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Sélectionner le dépôt Debian le plus rapide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Sources individuelles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Restaurer les sources APT d’origine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Afficher l’aide </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>À propos de cette application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>À propos…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Quitter l’application</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Appliquer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="191"/>
        <location filename="../src/mainwindow.cpp" line="662"/>
        <location filename="../src/mainwindow.cpp" line="1061"/>
        <source>Success</source>
        <translation>Installation réussie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <location filename="../src/mainwindow.cpp" line="663"/>
        <location filename="../src/mainwindow.cpp" line="1065"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Votre nouvelle sélection prendra effet la prochaine fois que les sources seront mises à jour.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="194"/>
        <source>No Changes</source>
        <translation>Aucun changement</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>The selected repository is already configured.</source>
        <translation>Le dépôt sélectionné est déjà configuré.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Lists</source>
        <translation>Listes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="404"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Sources (case cochée si déjà activée)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="949"/>
        <location filename="../src/mainwindow.cpp" line="964"/>
        <location filename="../src/mainwindow.cpp" line="977"/>
        <location filename="../src/mainwindow.cpp" line="984"/>
        <location filename="../src/mainwindow.cpp" line="998"/>
        <location filename="../src/mainwindow.cpp" line="1006"/>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="665"/>
        <source>Could not change the repo.</source>
        <translation>Impossible de modifier le dépôt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="690"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>Please wait...</source>
        <translation>Veuillez patienter…</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="784"/>
        <source>About %1</source>
        <translation>À propos de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="785"/>
        <source>Version: </source>
        <translation>Version : </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Programme pour le choix du dépôt APT par défaut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="789"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="790"/>
        <source>%1 License</source>
        <translation>%1 Licence</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="804"/>
        <source>%1 Help</source>
        <translation>%1 Aide</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="821"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="822"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Vous avez choisi le dépôt de test de MX. Il est déconseillé de le laisser activé ou de mettre à jour tous les paquets depuis ce même dépôt.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="825"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Une option plus sûre consiste à installer les paquets individuellement à l’aide de MX Package Installer « MX Installateur de paquets ».</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="862"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Sélectionnez le dépôt APT et les sources que vous souhaitez utiliser :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="928"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt n’a pas pu détecter le dépôt le plus rapide.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1068"/>
        <source>Could not restore the original APT source files.</source>
        <translation>Impossible de restaurer les fichiers source APT d’origine.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <location filename="../src/mainwindow.cpp" line="949"/>
        <location filename="../src/mainwindow.cpp" line="964"/>
        <source>Could not detect fastest repo.</source>
        <translation>Impossible de déterminer le dépôt le plus rapide.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="977"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>Impossible de savoir si cette application fonctionne sur antiX ou MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="985"/>
        <source>MX version not detected or out of range: </source>
        <translation>Version MX non détectée ou non disponible : </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="998"/>
        <source>Could not download original APT files.</source>
        <translation>Impossible de télécharger les fichiers APT originaux.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1006"/>
        <source>Could not unzip downloaded file.</source>
        <translation>Impossible de décompresser le fichier téléchargé.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>Enabling AHS</source>
        <translation>Activation AHS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>Utilisez-vous le dépôt AHS (Advanced Hardware Stack) ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1062"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Les sources APT d’origine ont été restaurées à leurs paramètres initiaux. Les sources entre-temps ajoutées par l’utilisateur dans /etc/apt/sources.list.d/ n’ont pas été modifiées.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="49"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="50"/>
        <location filename="../src/about.cpp" line="60"/>
        <source>Changelog</source>
        <translation>Journal des modifications</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="84"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Vous êtes apparemment connecté en tant que root, veuillez vous déconnecter et vous connecter en tant qu’utilisateur normal pour utiliser ce programme.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You must run this program with admin access.</source>
        <translation>Vous devez exécuter ce programme avec un accès administrateur.</translation>
    </message>
</context>
</TS>