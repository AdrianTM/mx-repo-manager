<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sv">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="17"/>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>MX Repo Manager</source>
        <translation>MX Repo Manager</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="32"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Välj det APT förråd du vill använda:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>MX förråd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Välj snabbaste MX förråd för mig</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>sök</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Debian förråd</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Välj snabbaste Debian förråd för mig</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Individuella källor</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Återställ original APT sources</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Visa hjälp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>Om detta program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Avsluta programmet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Använd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="937"/>
        <source>Success</source>
        <translation>Det lyckades</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="167"/>
        <location filename="../mainwindow.cpp" line="558"/>
        <location filename="../mainwindow.cpp" line="941"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Ditt nya val kommer att träda i kraft nästa gång förråden uppdateras.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Lists</source>
        <translation>Listor</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Förråd (markerade förråd är aktiva)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="805"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <location filename="../mainwindow.cpp" line="851"/>
        <location filename="../mainwindow.cpp" line="858"/>
        <location filename="../mainwindow.cpp" line="874"/>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <source>Could not change the repo.</source>
        <translation>Kunde inte ändra förrådet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="591"/>
        <source>Please wait...</source>
        <translation>Var vänlig vänta...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="667"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="668"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="670"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Program för att välja standard Apt förråd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="672"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <source>%1 License</source>
        <translation>%1 Licens</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="687"/>
        <source>%1 Help</source>
        <translation>%1 Hjälp</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="704"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="705"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Du har valt MX Test Repo. Det är inte rekommendabelt att lämna dom aktiverade eller att uppgradera alla paket från det.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="708"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Ett säkrare val är att installera paket individuellt med MX Paket Installerare.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Välj det APT-förråd och källor du vill använda:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="805"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt kunde inte hitta snabbaste förrådet.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <source>Could not detect fastest repo.</source>
        <translation>Kunde inte hitta snabbaste förrådet.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="851"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>Vet inte om den här appen fungerar med  antiX eller MX</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="859"/>
        <source>MX version not detected or out of range: </source>
        <translation>MX version ej hittad eller utanför skalan:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>Could not download original APT files.</source>
        <translation>Kunde inte ladda ner original APT filer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Could not unzip downloaded file.</source>
        <translation>Kunde inte packa upp den nedladdade filen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Enabling AHS</source>
        <translation>Möjliggör AHS</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>Använder du AHS (Advanced Hardware Stack) förråd?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="938"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Original APT sources har återställts till ursprunglig status. Source-filer tillagda av användare i /etc/apt/sources.list.d/ har inte ändrats.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="49"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="50"/>
        <location filename="../about.cpp" line="60"/>
        <source>Changelog</source>
        <translation>Ändringslogg</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Stäng</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <location filename="../main.cpp" line="82"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du verkar vara inloggad som root, var vänlig logga ut och logga in som vanlig användare för att använda detta program.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="83"/>
        <source>You must run this program with admin access.</source>
        <translation>Du måste köra detta program med administratörsrättigheter.</translation>
    </message>
</context>
</TS>