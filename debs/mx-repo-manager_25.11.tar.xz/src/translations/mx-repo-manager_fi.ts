<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="17"/>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>MX Repo Manager</source>
        <translation>MX Pakettilähteet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="32"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>Select the APT repository that you want to use:</source>
        <translation>Valitse apt-arkistot ja pakettilähteet.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation>MX-arkistot</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation>Valitse minulle nopein MX-arkisto</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>search</source>
        <translation>etsi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation>Debian-arkistot</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation>Valitse minulle nopein debian-arkisto</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation>Yksittäiset lähteet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation>Palauta alkuperäiset lähteet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>Näytä ohje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>Tietoja sovelluksesta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>Tietoja...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>Lopeta sovellus</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation>Hyväksy</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="937"/>
        <source>Success</source>
        <translation>Onnistui</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="167"/>
        <location filename="../mainwindow.cpp" line="558"/>
        <location filename="../mainwindow.cpp" line="941"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation>Valintasi tulee käyttöön ensi kerralla kun lähteet päivitetään.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Lists</source>
        <translation>Luettelot</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Sources (checked sources are enabled)</source>
        <translation>Lähteet (valitut ovat käytössä)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="805"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <location filename="../mainwindow.cpp" line="851"/>
        <location filename="../mainwindow.cpp" line="858"/>
        <location filename="../mainwindow.cpp" line="874"/>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <source>Could not change the repo.</source>
        <translation>Arkiston vaihtaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="591"/>
        <source>Please wait...</source>
        <translation>Odota, ole hyvä...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="667"/>
        <source>About %1</source>
        <translation>%1 lisätietoja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="668"/>
        <source>Version: </source>
        <translation>Versio: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="670"/>
        <source>Program for choosing the default APT repository</source>
        <translation>Ohjelma oletus apt-arkiston valintaan</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="672"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <source>%1 License</source>
        <translation>%1 lisenssi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="687"/>
        <source>%1 Help</source>
        <translation>%1 ohje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="704"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="705"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation>Valitsit MX-testiarkiston. Pidempää käyttöä tai kaikkien pakettien päivittämistä siitä ei suositella.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="708"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation>Turvallisempi tapa on asentaa paketit yksi kerrallaan MX Sovellukset asennus ohjelmalla.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation>Valitse apt-arkistot ja pakettivarastot:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="805"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation>netselect-apt ei tunnistanut nopeinta arkistoa.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <source>Could not detect fastest repo.</source>
        <translation>Nopeinta arkistoa ei tunnistettu.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="851"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation>En pysty selvittämään, onko tämä sovellus käynnissä antiX vai MX järjestelmässä</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="859"/>
        <source>MX version not detected or out of range: </source>
        <translation>MX-versiota ei havaittu tai se on alueen ulkopuolella:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>Could not download original APT files.</source>
        <translation>Alkuperäisiä APT-tiedostoja ei voitu ladata.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Could not unzip downloaded file.</source>
        <translation>Ladattua tiedostoa ei voitu purkaa.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Enabling AHS</source>
        <translation>AHS käyttöön</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation>Käytätkö AHS (Advanced Hardware Stack) arkistoa?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="938"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation>Alkuperäiset APT-lähteet ovat palautetut julkaisuun nähden. Käyttäjän lisäämiin lähdetiedostoihin kohteessa /etc/apt/sources.list.d/ ei koskettu.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="49"/>
        <source>License</source>
        <translation>Lisenssi</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="50"/>
        <location filename="../about.cpp" line="60"/>
        <source>Changelog</source>
        <translation>Muutosloki</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <location filename="../main.cpp" line="82"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Olet kirjautunut sisään pääkäyttäjänä. Kirjaudu sisään normaalina käyttäjänä käyttääksesi tätä ohjelmaa.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="83"/>
        <source>You must run this program with admin access.</source>
        <translation>Tämä ohjelma on suoritettava järjestelmänvalvojan oikeuksilla.</translation>
    </message>
</context>
</TS>