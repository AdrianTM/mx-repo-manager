<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ar">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="17"/>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>MX Repo Manager</source>
        <translation>مدير مستودعات لام اكس</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="32"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <source>Select the APT repository that you want to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>MX repos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="84"/>
        <source>Select fastest MX repo for me</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>search</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Debian repos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="180"/>
        <source>Select fastest Debian repo for me</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Individual sources</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="248"/>
        <source>Restore original APT sources</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="329"/>
        <source>Display help </source>
        <translation>إظهار المساعدة</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Help</source>
        <translation>مساعدة</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Alt+H</source>
        <translation>Alt+H&lt;br&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>About this application</source>
        <translation>إيقاف هذا التطبيق</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="386"/>
        <source>About...</source>
        <translation>عن...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="408"/>
        <source>Quit application</source>
        <translation>إنهاء التطبيق</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Close</source>
        <translation>إغلاق</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="417"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="436"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <location filename="../mainwindow.cpp" line="557"/>
        <location filename="../mainwindow.cpp" line="937"/>
        <source>Success</source>
        <translation>ناجح</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="167"/>
        <location filename="../mainwindow.cpp" line="558"/>
        <location filename="../mainwindow.cpp" line="941"/>
        <source>Your new selection will take effect the next time sources are updated.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Lists</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Sources (checked sources are enabled)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="805"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <location filename="../mainwindow.cpp" line="851"/>
        <location filename="../mainwindow.cpp" line="858"/>
        <location filename="../mainwindow.cpp" line="874"/>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Error</source>
        <translation>خطأ</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <source>Could not change the repo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="591"/>
        <source>Please wait...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="667"/>
        <source>About %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="668"/>
        <source>Version: </source>
        <translation>الإصدار:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="670"/>
        <source>Program for choosing the default APT repository</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="672"/>
        <source>Copyright (c) MX Linux</source>
        <translation>حقوق النشر  (MX linux (c</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <source>%1 License</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="687"/>
        <source>%1 Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="704"/>
        <source>Warning</source>
        <translation>تحذير</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="705"/>
        <source>You have selected MX Test Repo. It&apos;s not recommended to leave it enabled or to upgrade all the packages from it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="708"/>
        <source>A safer option is to install packages individually with MX Package Installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="745"/>
        <source>Select the APT repository and sources that you want to use:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="805"/>
        <source>netselect-apt could not detect fastest repo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="784"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <source>Could not detect fastest repo.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="851"/>
        <source>Can&apos;t figure out if this app is running on antiX or MX</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="859"/>
        <source>MX version not detected or out of range: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>Could not download original APT files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>Could not unzip downloaded file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Enabling AHS</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="924"/>
        <source>Do you use AHS (Advanced Hardware Stack) repo?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="938"/>
        <source>Original APT sources have been restored to the release status. User added source files in /etc/apt/sources.list.d/ have not been touched.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="49"/>
        <source>License</source>
        <translation>رخصة</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="50"/>
        <location filename="../about.cpp" line="60"/>
        <source>Changelog</source>
        <translation>التغيرات</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>Cancel</source>
        <translation>إلغاء</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>&amp;Close</source>
        <translation>&amp;اغلاق</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="73"/>
        <location filename="../main.cpp" line="82"/>
        <source>Error</source>
        <translation>خطأ</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="74"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="83"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>